package com.me.mygdxgame;

import com.badlogic.gdx.graphics.g2d.Animation;

public class EnemyType {
	
	public int health;
	public float speed;
	public int damage;
	public int points;
	public Animation[][] animations;
	public int width;
	public int height;

}
