package com.me.mygdxgame;

public class PlayerType 
{
	public int health;
	public int comboThreshold;
	
	public PlayerType(int health, int comboThreshold)
	{
		this.health = health;
		this.comboThreshold = comboThreshold;
	}
}
